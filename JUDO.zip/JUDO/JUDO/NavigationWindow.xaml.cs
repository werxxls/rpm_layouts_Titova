﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JUDO
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class NavigationWindow : Window
    {
        public NavigationWindow()
        {
            InitializeComponent();
        }

        private void ButtonRegistrationParticipant_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow reg = new RegistrationWindow();
            reg.Show();
        }

        private void ButtonGroup_Click(object sender, RoutedEventArgs e)
        {
            GroupWindow groip = new GroupWindow();
            groip.Show();
        }

        private void ButtonMeeting_Click(object sender, RoutedEventArgs e)
        {
            MeetingWindow meet = new MeetingWindow();
            meet.Show();
        }

        private void ButtonCompetitions_Click(object sender, RoutedEventArgs e)
        {
            CompetitionsWindow com = new CompetitionsWindow();
            com.Show();
        }

        private void ButtonManagmentCompetitions_Click(object sender, RoutedEventArgs e)
        {
            ManagmentWindow man = new ManagmentWindow();
            man.Show();
        }

        private void ButtonDiplom_Click(object sender, RoutedEventArgs e)
        {DiplomWindow dip = new DiplomWindow();
            dip.Show();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
