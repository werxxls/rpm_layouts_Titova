﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JUDO
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            NavigationWindow nav = new NavigationWindow();
            nav.Show();
        }

        private void ButtonLoginGuest_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonChangePassword_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonForgotPassword_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
