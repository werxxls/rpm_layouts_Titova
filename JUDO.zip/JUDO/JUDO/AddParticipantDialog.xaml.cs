﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JUDO
{
    /// <summary>
    /// Логика взаимодействия для AddParticipantDialog.xaml
    /// </summary>
    public partial class AddParticipantDialog : Window
    {
        public AddParticipantDialog()
        {
            InitializeComponent();
        }

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonAddS_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
