﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JUDO
{
    /// <summary>
    /// Логика взаимодействия для RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonSearchSort_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            AddParticipantDialog ed = new AddParticipantDialog();
            ed.Show();
        }

        private void ButtonEdit_Click(object sender, RoutedEventArgs e)
        {
            EditParticipantDialog ed = new EditParticipantDialog();
            ed.Show();
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonImport_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonFinishRegistration_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow log = new LoginWindow();
            log.Show();
        }

        private void ButtonNext_Click(object sender, RoutedEventArgs e)
        {
            GroupWindow groip = new GroupWindow();
            groip.Show();
            this.Close();
        }
    }
}
