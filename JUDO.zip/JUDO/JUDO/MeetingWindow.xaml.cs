﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JUDO
{
    /// <summary>
    /// Логика взаимодействия для MeetingWindow.xaml
    /// </summary>
    public partial class MeetingWindow : Window
    {
        public MeetingWindow()
        {
            InitializeComponent();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonSearchSort_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonPrint_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            GroupWindow groip = new GroupWindow();
            groip.Show();
        }

        private void ButtonNext_Click(object sender, RoutedEventArgs e)
        {
            CompetitionsWindow com = new CompetitionsWindow();
            com.Show();
        }
    }
}
